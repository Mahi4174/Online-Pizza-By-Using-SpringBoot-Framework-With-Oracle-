package com.example.tables;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PizzaStore {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String storename;
	private String location;
	@Override
	public String toString() {
		return "Store [id=" + id + ", storename=" + storename + ", location=" + location + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public PizzaStore() {}
	public PizzaStore(Integer id, String storename, String location) {
		super();
		this.id = id;
		this.storename = storename;
		this.location = location;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
