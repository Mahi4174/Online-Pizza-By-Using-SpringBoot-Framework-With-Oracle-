package com.example.tables;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class CreditCardDetails {
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private Integer id;
	public CreditCardDetails()
	{}	
	public CreditCardDetails(Integer id, BigDecimal creditCardNumber, String name, BigDecimal balance) {
		super();
		this.id = id;
		CreditCardNumber = creditCardNumber;
		this.name = name;
		Balance = balance;
	}
	@Override
	public String toString() {
		return "CreditCard [id=" + id + ", CreditCardNumber=" + CreditCardNumber + ", name=" + name + ", Balance="
				+ Balance + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public BigDecimal getCreditCardNumber() {
		return CreditCardNumber;
	}
	public void setCreditCardNumber(BigDecimal creditCardNumber) {
		CreditCardNumber = creditCardNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getBalance() {
		return Balance;
	}
	public void setBalance(BigDecimal balance) {
		Balance = balance;
	}
	private BigDecimal CreditCardNumber;
	private String name;
	private BigDecimal Balance;

}

