package com.example.tables;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Pizza {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String storename;
	
	public Pizza( String storename, String name, String category, String description, int prize) {
		
		this.storename = storename;
		this.name = name;
		this.category = category;
		this.description = description;
		this.prize = prize;
	}
	@Override
	public String toString() {
		return "Food [id=" + id + ", storename=" + storename + ", name=" + name + ", category=" + category
				+ ", description=" + description + ", prize=" + prize + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrize() {
		return prize;
	}
	public void setPrize(int prize) {
		this.prize = prize;
	}
	private String name;
	private String category;
	private String description;
	private int prize;
	public Pizza(){}
	
	
}
