package com.example;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.repositories.AdminRepository;
import com.example.repositories.CreditCardRepository;
import com.example.repositories.UserRepository;
import com.example.repositories.PizzaRepository;
import com.example.repositories.UserRegistrationRepository;
import com.example.repositories.PizzaStoreRepository;
import com.example.tables.Admin;
import com.example.tables.CreditCardDetails;

import com.example.tables.Pizza;
import com.example.tables.PizzaUser;
import com.example.tables.RegistrationUser;

@Controller
public class MyController {
	@Autowired
	AdminRepository adminRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	UserRegistrationRepository userRegistrationRepository;
	@Autowired
	PizzaRepository pizzaRepository;
	@Autowired
	PizzaStoreRepository pizzaStoreRepository;
	@Autowired
	CreditCardRepository creditCardRepository;
	
	

	
	
	ArrayList<BigDecimal> ab_user=new ArrayList<>();
	ArrayList<String> u=new ArrayList<>();
	ArrayList<Integer> al=new ArrayList<>();	


	@GetMapping("/")
	public String greet() {
		return "index";
	}
	@GetMapping("/signin")
	public String login(Model model, @RequestParam(value = "name") String user, @RequestParam(value="password") String userpassword, @RequestParam("radioName") String a) {
		try {
			Admin a1=new Admin("pravalika","pravalika");
			adminRepository.save(a1);
		
			int flag=0;
			if(a.equals("admin")) {
				List<Admin> admintable= (List<Admin>) adminRepository.findAll();
				for(int i=0;i<admintable.size();i++) {
					String name=admintable.get(i).getName();
					String password=admintable.get(i).getPassword();
					if(name.equals(user) && password.equals(userpassword)) {
						flag=1;
						break;
					}
					
				}
				
			}else {
				PizzaUser p = new PizzaUser(user,userpassword);
				List<PizzaUser> usertable= (List<PizzaUser>) userRepository.findAll();
				for(int i=0;i<usertable.size();i++) {
					String name=usertable.get(i).getName();
					String password=usertable.get(i).getPassword();
					if(name.equals(user) && password.equals(userpassword)) {
						flag=1;
						
						break;
					}
					
				}
				
			}
			
			
			if(flag==1 && a.equals("admin")) {
				System.out.println("admin logged successfully");
				model.addAttribute("msg", "admin have logged in successfully");
				return "adminindex";
			}else if(flag==1 && a.equals("User")) {
				System.out.println("user logged in successfully");
				model.addAttribute("msg", "user have logged in successfully");
				List<RegistrationUser> userRegtable= (List<RegistrationUser>) userRegistrationRepository.findAll();
				for(int i=0;i<userRegtable.size();i++) {
					String n=userRegtable.get(i).getUsername();
					if(n.equals(user)) {
						BigDecimal crno=userRegtable.get(i).getCreditcardnumber();
						BigDecimal bal=userRegtable.get(i).getBalance();
						ab_user.add(crno);
						u.add(n);
						break;
						
					}
				}
				return "userindex";
				
			}else if(flag==0 && a.equals("admin")) {
				System.out.println("else block");
				model.addAttribute("msg", "admin details does not exist !");
				return "registration";	
			}else {
				System.out.println("user details  does not exist");
				
				model.addAttribute("msg", "user details does not exist !");
				return "registration";
				
			}
			
			
			
			
		} catch (Exception e) {
			model.addAttribute("msg", "User details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
	@GetMapping("/register")
	public String register(Model model, @RequestParam(value = "username") String username, @RequestParam(value="firstname") String firstname,
			@RequestParam(value = "lastname") String lastname, @RequestParam(value = "password") String password,@RequestParam(value = "email") String email,
			@RequestParam(value = "contactnumber") Long contactnumber, @RequestParam(value = "city") String city, @RequestParam(value = "state") String state,@RequestParam("radioName") String a,@RequestParam(value="creditcardnumber") BigDecimal cno,@RequestParam(value="balance") BigDecimal bal) {
		try {
				System.out.println("-------------------------------------------------------");
				RegistrationUser p = new RegistrationUser(username,firstname,lastname,password,email,contactnumber,city,state,cno,bal);
				userRegistrationRepository.save(p);
				PizzaUser p1=new PizzaUser(firstname,password);
				userRepository.save(p1);
				model.addAttribute("msg", "User details  registered saved successfully !");
				System.out.println("hi");
				return "login";
				
			}
			
			

		 catch (Exception e) {
			model.addAttribute("msg", "User details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
	@GetMapping("/passwordchange")
	public String chagne(Model model,@RequestParam(value="name") String n,@RequestParam(value="password") String p1,@RequestParam(value="confirmpassword") String p2) {
		boolean flag=false;
		List<PizzaUser> p= (List<PizzaUser>) userRepository.findAll();
		if(p1.equals(p2)) {
			for(int i=0;i<p.size();i++) {
				String name=p.get(i).getName();
				if(name.equals(n)) {
					p.get(i).setPassword(p1);
					userRepository.saveAll(p);
					
				}
			}
		}
	   model.addAttribute("msg","Password Changed Successfully");
		return "success";
	}
	@GetMapping("/addpizza")
	public String add() {
		return "addpizza";
	}
	@PostMapping("/add")
	public String addFoodItem(Model model, @RequestParam(value="storename") String storename,@RequestParam(value = "name") String name,@RequestParam("category") String c,@RequestParam(value="description") String description,@RequestParam(value="prize") int prize) {
		try {
			Pizza p=new Pizza(storename,name,c,description,prize);
			pizzaRepository.save(p);
			
			model.addAttribute("msg", "Food Item saved successfully !");
			return "sucess";
		} catch (Exception e) {
			model.addAttribute("msg", "Food Item couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
	
	
	@RequestMapping(value = "/cartredirect", method=RequestMethod.GET)
	public String addcart(Model model,@RequestParam(value="prize") Integer p ) {
		int sum=0;
	   al.add(p);
	   List<Pizza> items = (List<Pizza>) pizzaRepository.findAll();  
		model.addAttribute("fooditems", items);
		model.addAttribute("l1",al);
		for(int i=0;i<al.size();i++) {
			sum += al.get(i);
		}
		model.addAttribute("total",sum);
		return "mycart";
	}
	
	@GetMapping( "/cartremove")
	public String cartremove(Model model,@RequestParam(value="prize") Integer p ) {
		int sum=0;
		al.remove(p);
	  
	   List<Pizza> items = (List<Pizza>) pizzaRepository.findAll();  
		model.addAttribute("fooditems", items);
		model.addAttribute("l1",al);
		for(int i=0;i<al.size();i++) {
			sum += al.get(i);
		}
		model.addAttribute("total",sum);
		return "mycart";
	}

	
	
	
	@GetMapping("/logout")
	public String chagne(Model model) {
		al.removeAll(al);
	   model.addAttribute("msg","You have Successfully logged out");
		return "login";
	}
	@GetMapping("/deleteredirect")
	public String deleteredirect(Model model) {
		ArrayList<Integer> ids=new ArrayList<>();
		List<Pizza> f=(List<Pizza>) pizzaRepository.findAll();
		model.addAttribute("items",f);
		
		return "delete";
	}
	@GetMapping("/storeredirect")
	public String storeredirect() {
		return "store";
	}
	@GetMapping("/gotostore")
	public String gotostore() {
		return "addpizza";
	}
	@GetMapping("/delete")
	public String profile(Model model,@RequestParam(value="id") int id1) {
		
		pizzaRepository.deleteById(id1);		
		return "success";
	}
	@GetMapping("/orderredirect")
	public String order(Model model) {
		List<CreditCardDetails> o=(List<CreditCardDetails>)creditCardRepository.findAll();
		model.addAttribute("t_o", o.size());
				
		return "orders";
	}
	@GetMapping("/viewfooditems")
	public String viewfooditems(Model model) {
		List<Pizza> items = (List<Pizza>) pizzaRepository.findAll();
		model.addAttribute("fooditems", items);
		List<Pizza> f=(List<Pizza>) pizzaRepository.findAll();
		for(int i=0;i<f.size();i++) {
			System.out.println("ids avaliable "+f.get(i).getId());
		}
		return "adminview";
	}
	ArrayList<BigDecimal> ab=new ArrayList<>();
	
	@GetMapping("/paymentredirect")
	
	public String payment1(Model model) {
		int sum=0;
		for(int i=0;i<al.size();i++) {
			sum += al.get(i);
		}
	System.out.println("u size is "+u.size());
	
		if(u.size()>1) {
			int len=u.size();
			model.addAttribute("u_name",u.get(len-1));
			model.addAttribute("c_no",ab_user.get(len-1));
			model.addAttribute("cost",sum);
			
		}else {
			model.addAttribute("u_name",u.get(0));
			model.addAttribute("c_no",ab_user.get(0));
			model.addAttribute("cost",sum);
		}
		
		
		return "paymentform";
	}
	@GetMapping("/payment")
	public String payment(Model model,@RequestParam(value="amount") BigDecimal amount_deducted) {
		List<RegistrationUser> p3= (List<RegistrationUser>) userRegistrationRepository.findAll();
		List<CreditCardDetails> p0=(List<CreditCardDetails>) creditCardRepository.findAll();
		System.out.println(u.get(0)+"u is "+u);
		System.out.println("al is "+al.get(0)+ " al is "+al);
		System.out.println("ab_user is "+ab_user);
		
		for(int i=0;i<p3.size();i++) {
			String name=p3.get(i).getFirstname();
			if(u.get(0).equals(name)) {
				BigDecimal c_n=p3.get(i).getBalance();
				BigDecimal diff=c_n.subtract(amount_deducted);
				p3.get(i).setBalance(diff);
				CreditCardDetails c=new CreditCardDetails(0,c_n,name,diff);
				creditCardRepository.save(c);
				userRegistrationRepository.saveAll(p3);
				
				System.out.println("balance is ======================================== "+p3.get(i).getBalance());
				
				break;
			}
		}
		List<CreditCardDetails> p6=(List<CreditCardDetails>) creditCardRepository.findAll();
		System.out.println("p0  length is "+p6);
		model.addAttribute("msg","Your Order placed Successfully");
		
		
		
		
		return "success";
	}
	
	
	

	
	
	
	@GetMapping("/viewredirect")
	public String view(Model model) {
		List<Pizza> items = (List<Pizza>) pizzaRepository.findAll();
		model.addAttribute("fooditems", items);
		
		return "view";
		
	}


}
