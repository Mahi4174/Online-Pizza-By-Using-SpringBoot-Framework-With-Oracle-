package com.example.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.tables.PizzaStore;


public interface PizzaStoreRepository  extends CrudRepository<PizzaStore, Integer> {

}

