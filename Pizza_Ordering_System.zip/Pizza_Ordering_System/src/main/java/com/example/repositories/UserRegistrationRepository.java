package com.example.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.tables.RegistrationUser;




public interface UserRegistrationRepository extends CrudRepository<RegistrationUser, Integer>{

}

