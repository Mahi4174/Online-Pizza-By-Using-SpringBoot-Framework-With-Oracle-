package com.example.repositories;
import org.springframework.data.repository.CrudRepository;

import com.example.tables.Admin;



public interface AdminRepository extends CrudRepository<Admin, Integer>{



}

