package com.example.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.tables.PizzaUser;



public interface UserRepository extends CrudRepository<PizzaUser, Integer>{
  public PizzaUser findByName(String name);
}

